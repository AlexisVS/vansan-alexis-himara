  <div class="sidebar">
    <aside class="widget noborder">
      <div class="search">
        <form class="widget-search">
          <input type="search" placeholder="Search">
          <button class="btn-search" id="searchsubmit" type="submit">
            <i class="fa fa-search"></i>
          </button>
        </form>
      </div>
    </aside>
    <!-- WIDGET -->
    <aside class="widget">
      <h4 class="widget-title">CATEGORIES</h4>
      <ul class="categories">
        <li>
          <a href="#">Single Room<span class="posts-num">51</span></a>
        </li>
        <li>
          <a href="#">Double Room<span class="posts-num">24</span></a>
        </li>
        <li>
          <a href="#">Family Room
            <span class="posts-num">9</span></a>
        </li>
        <li>
          <a href="#">Deluxe Room<span class="posts-num">12</span></a>
        </li>
      </ul>
    </aside>
    <!-- WIDGET -->
    <aside class="widget">
      <h4 class="widget-title">Tags</h4>
      <div class="tagcloud">
        <a href="#">
          <span class="tag">Red</span></a>
        <a href="#">
          <span class="tag">Dark</span></a>
        <a href="#">
          <span class="tag">Yellow</span></a>
        <a href="#">
          <span class="tag">Blue</span></a>
        <a href="#">
          <span class="tag">Pink</span></a>
        <a href="#">
          <span class="tag">Green</span></a>
        <a href="#">
          <span class="tag">Gray</span></a>
        <a href="#">
          <span class="tag">Brown</span></a>
      </div>
    </aside>
  </div>
<?php /**PATH C:\laragon\www\vansan-alexis-himara\resources\views/front/partials/pages/rooms-list/sidebar.blade.php ENDPATH**/ ?>