<section class="video np parallax gradient-overlay op6" data-src="<?php echo e(asset('images/video.jpg')); ?>" data-parallax="scroll"
  data-speed="0.3" data-mirror-selector=".wrapper" data-z-index="0">
  <div class="inner gradient-overlay">
    <div class="container">
      <div class="video-popup">
        <a class="popup-vimeo" href="https://www.youtube.com/watch?v=BDDfopejpwk">
          <i class="fa fa-play"></i>
        </a>
      </div>
    </div>
  </div>
</section>
<?php /**PATH C:\laragon\www\vansan-alexis-himara\resources\views/front/partials/pages/home/video.blade.php ENDPATH**/ ?>