<div class="section-title sm">
  <h4>ROOM SERVICES</h4>
  <p class="section-subtitle">Istanbul Includes</p>
</div>
<?php /**PATH C:\laragon\www\vansan-alexis-himara\resources\views/front/partials/pages/room/section-title.blade.php ENDPATH**/ ?>