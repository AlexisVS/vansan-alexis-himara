<div id="booking-notification" class="notification fixed"></div>
<?php /**PATH C:\laragon\www\vansan-alexis-himara\resources\views/front/partials/layout/booking-notification.blade.php ENDPATH**/ ?>