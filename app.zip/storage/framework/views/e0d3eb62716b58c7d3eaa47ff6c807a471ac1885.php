<div class="notification"></div>
<?php /**PATH C:\laragon\www\vansan-alexis-himara\resources\views/front/partials/layout/notification.blade.php ENDPATH**/ ?>