<div class="back-to-top">
  <i class="fa fa-angle-up" aria-hidden="true"></i>
</div>
<?php /**PATH C:\laragon\www\vansan-alexis-himara\resources\views/front/partials/layout/back-to-top.blade.php ENDPATH**/ ?>