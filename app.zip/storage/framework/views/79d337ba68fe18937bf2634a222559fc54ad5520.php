<div id="contact-notification" class="notification fixed"></div>
<?php /**PATH C:\laragon\www\vansan-alexis-himara\resources\views/front/partials/layout/contact-notification.blade.php ENDPATH**/ ?>