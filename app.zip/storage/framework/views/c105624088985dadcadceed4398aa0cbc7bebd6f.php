
<?php $__env->startSection('content'); ?>
  
  <?php echo $__env->make('front.partials.layout.top-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  
  <?php echo $__env->make('front.partials.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  
  <?php echo $__env->make('front.partials.pages.contact.page-title', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <main class="contact-page">
    <div class="container">
      <div class="row">
        <div class="col-md-8">
          <div class="section-title">
            <h4>CONTACT US</h4>
            <p class="section-subtitle">Let’s Talk</p>
          </div>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Possimus sit, fugiat at in assumenda corrupti autem
            iste eveniet eaque vitae beatae tenetur, voluptatem eius. Numquam.
          </p>
          <?php echo $__env->make('front.partials.pages.contact.contact-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="col-md-4">
          <?php echo $__env->make('front.partials.pages.contact.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
      </div>
    </div>
  </main>
  <?php echo $__env->make('front.partials.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('after_wrapper'); ?>
  <?php echo $__env->make('front.partials.layout.contact-notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vansan-alexis-himara\resources\views/front/pages/contact.blade.php ENDPATH**/ ?>