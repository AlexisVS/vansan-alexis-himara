<div class="loader loader3">
  <div class="loader-inner">
    <div class="spin">
      <span></span>
      <img src="<?php echo e(asset('images/logo.svg')); ?>" alt="Hotel Himara">
    </div>
  </div>
</div>
<?php /**PATH C:\laragon\www\vansan-alexis-himara\resources\views/front/partials/layout/preloader.blade.php ENDPATH**/ ?>