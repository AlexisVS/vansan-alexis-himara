<form id="contact-form" class="contact-form">
  <div class="form-group">
    <input class="form-control" name="name" placeholder="Name" type="text">
  </div>
  <div class="form-group">
    <input class="form-control" name="email" placeholder="Email" type="email">
  </div>
  <div class="form-group">
    <input class="form-control" name="phone" placeholder="Phone" type="text">
  </div>
  <div class="form-group">
    <input class="form-control" name="subject" placeholder="Subject" type="text">
  </div>
  <div class="form-group">
    <textarea class="form-control" name="message" placeholder="Message"></textarea>
  </div>
  <div class="form-group">
    <button class="btn mt30">SEND YOUR MESSAGE</button>
  </div>
</form>
<?php /**PATH C:\laragon\www\vansan-alexis-himara\resources\views/front/partials/pages/contact/contact-form.blade.php ENDPATH**/ ?>