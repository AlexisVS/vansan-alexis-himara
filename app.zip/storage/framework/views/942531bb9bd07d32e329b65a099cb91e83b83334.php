
<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('front.partials.layout.top-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('front.partials.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('front.partials.pages.rooms-list.page-title', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <main class="rooms-list-view">
    <div class="container">
      <div class="row">
        <div class="col-lg-9 col-12">
          <?php echo $__env->make('front.partials.pages.rooms-list.rooms-list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="col-lg-3 col-12">
          <?php echo $__env->make('front.partials.pages.rooms-list.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
      </div>
    </div>
  </main>
  <?php echo $__env->make('front.partials.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('after-wrapper'); ?>
  <?php echo $__env->make('front.partials.layout.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vansan-alexis-himara\resources\views/front/pages/rooms-list.blade.php ENDPATH**/ ?>