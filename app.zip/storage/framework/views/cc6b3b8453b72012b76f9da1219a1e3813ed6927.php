<div class="page-title gradient-overlay op5" style="background: url('<?php echo e(asset('images/breadcrumb.jpg')); ?>'); background-repeat: no-repeat;
background-size: cover;">
  <div class="container">
    <div class="inner">
      <h1>ISTANBUL</h1>
      <div class="room-details-price">
        €89 / NIGHT
      </div>
      <ol class="breadcrumb">
        <li>
          <a href="/">Home</a>
        </li>
        <li>
          <a href="/room">Rooms</a>
        </li>
        <li>Istanbul</li>
      </ol>
    </div>
  </div>
</div>
<?php /**PATH C:\laragon\www\vansan-alexis-himara\resources\views/front/partials/pages/room/page-title.blade.php ENDPATH**/ ?>