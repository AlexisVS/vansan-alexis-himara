<div class="room-services-list">
  <div class="row">
    <div class="col-sm-4">
      <ul class="list-unstyled">
        <li>
          <i class="fa fa-check"></i>Double Bed
        </li>
        <li>
          <i class="fa fa-check"></i>80 Sq mt
        </li>
        <li>
          <i class="fa fa-check"></i>3 Persons
        </li>
        <li>
          <i class="fa fa-check"></i>Free Internet
        </li>
      </ul>
    </div>
    <div class="col-sm-4">
      <ul class="list-unstyled">
        <li>
          <i class="fa fa-check"></i>Free Wi-Fi
        </li>
        <li>
          <i class="fa fa-check"></i>Breakfast Include
        </li>
        <li>
          <i class="fa fa-check"></i>Private Balcony
        </li>
        <li class="no">
          <i class="fa fa-times"></i>Free Newspaper
        </li>
      </ul>
    </div>
    <div class="col-sm-4">
      <ul class="list-unstyled">
        <li class="no">
          <i class="fa fa-times"></i>Flat Screen Tv
        </li>
        <li>
          <i class="fa fa-check"></i>Full Ac
        </li>
        <li class="no">
          <i class="fa fa-times"></i>Beach View
        </li>
        <li>
          <i class="fa fa-check"></i>Room Service
        </li>
      </ul>
    </div>
  </div>
</div>
