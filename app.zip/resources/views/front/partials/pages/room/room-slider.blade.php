<div class="room-slider">
  <div id="room-main-image" class="owl-carousel image-gallery">
    <!-- ITEM -->
    <div class="item">
      <figure class="gradient-overlay-hover image-icon">
        <a href="images/rooms/single/single1.jpg">
          <img class="img-fluid" src="images/rooms/single/single1.jpg" alt="Image">
        </a>
      </figure>
    </div>
    <!-- ITEM -->
    <div class="item">
      <figure class="gradient-overlay-hover image-icon">
        <a href="images/rooms/single/single2.jpg">
          <img class="img-fluid" src="images/rooms/single/single2.jpg" alt="Image">
        </a>
      </figure>
    </div>
    <!-- ITEM -->
    <div class="item">
      <figure class="gradient-overlay-hover image-icon">
        <a href="images/rooms/single/single3.jpg">
          <img class="img-fluid" src="images/rooms/single/single3.jpg" alt="Image">
        </a>
      </figure>
    </div>
    <!-- ITEM -->
    <div class="item">
      <figure class="gradient-overlay-hover image-icon">
        <a href="images/rooms/single/single4.jpg">
          <img class="img-fluid" src="images/rooms/single/single4.jpg" alt="Image">
        </a>
      </figure>
    </div>
    <!-- ITEM -->
    <div class="item">
      <figure class="gradient-overlay-hover image-icon">
        <a href="images/rooms/single/single5.jpg">
          <img class="img-fluid" src="images/rooms/single/single5.jpg" alt="Image">
        </a>
      </figure>
    </div>
    <!-- ITEM -->
    <div class="item">
      <figure class="gradient-overlay-hover image-icon">
        <a href="images/rooms/single/single6.jpg">
          <img class="img-fluid" src="images/rooms/single/single6.jpg" alt="Image">
        </a>
      </figure>
    </div>
    <!-- ITEM -->
    <div class="item">
      <figure class="gradient-overlay-hover image-icon">
        <a href="images/rooms/single/single7.jpg">
          <img class="img-fluid" src="images/rooms/single/single7.jpg" alt="Image">
        </a>
      </figure>
    </div>
    <!-- ITEM -->
    <div class="item">
      <figure class="gradient-overlay-hover image-icon">
        <a href="images/rooms/single/single8.jpg">
          <img class="img-fluid" src="images/rooms/single/single8.jpg" alt="Image">
        </a>
      </figure>
    </div>
  </div>
  <div id="room-thumbs" class="room-thumbs owl-carousel">
    <!-- ITEM -->
    <div class="item"><img class="img-fluid" src="images/rooms/single/single1.jpg" alt="Image"></div>
    <!-- ITEM -->
    <div class="item"><img class="img-fluid" src="images/rooms/single/single2.jpg" alt="Image"></div>
    <!-- ITEM -->
    <div class="item"><img class="img-fluid" src="images/rooms/single/single3.jpg" alt="Image"></div>
    <!-- ITEM -->
    <div class="item"><img class="img-fluid" src="images/rooms/single/single4.jpg" alt="Image"></div>
    <!-- ITEM -->
    <div class="item"><img class="img-fluid" src="images/rooms/single/single5.jpg" alt="Image"></div>
    <!-- ITEM -->
    <div class="item"><img class="img-fluid" src="images/rooms/single/single6.jpg" alt="Image"></div>
    <!-- ITEM -->
    <div class="item"><img class="img-fluid" src="images/rooms/single/single7.jpg" alt="Image"></div>
    <!-- ITEM -->
    <div class="item"><img class="img-fluid" src="images/rooms/single/single8.jpg" alt="Image"></div>
  </div>
</div>
