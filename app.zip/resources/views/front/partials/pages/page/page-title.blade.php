<div class="page-title gradient-overlay op6" style="background: url('{{ asset('images/breadcrumb.jpg') }}'); background-repeat: no-repeat;
background-size: cover;">
  <div class="container">
    <div class="inner">
      <h1>RIGHT SIDEBAR PAGE</h1>
      <ol class="breadcrumb">
        <li>
          <a href="/">Home</a>
        </li>
        <li>Right Sidebar Page</li>
      </ol>
    </div>
  </div>
</div>
