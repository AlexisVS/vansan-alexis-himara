<div class="row image-gallery">
  <!-- ITEM -->
  <div class="col-md-3">
    <figure class="gradient-overlay-hover image-icon">
      <a href="images/events/event/event1.jpg">
        <img src="images/events/event/event1.jpg" class="img-fluid" alt="Image">
      </a>
    </figure>
  </div>
  <!-- ITEM -->
  <div class="col-md-3">
    <figure class="gradient-overlay-hover image-icon">
      <a href="images/events/event/event2.jpg">
        <img src="images/events/event/event2.jpg" class="img-fluid" alt="Image">
      </a>
    </figure>
  </div>
  <!-- ITEM -->
  <div class="col-md-3">
    <figure class="gradient-overlay-hover image-icon">
      <a href="images/events/event/event3.jpg">
        <img src="images/events/event/event3.jpg" class="img-fluid" alt="Image">
      </a>
    </figure>
  </div>
  <!-- ITEM -->
  <div class="col-md-3">
    <figure class="gradient-overlay-hover image-icon">
      <a href="images/events/event/event4.jpg">
        <img src="images/events/event/event4.jpg" class="img-fluid" alt="Image">
      </a>
    </figure>
  </div>
  <!-- ITEM -->
  <div class="col-md-3">
    <figure class="gradient-overlay-hover image-icon">
      <a href="images/events/event/event5.jpg">
        <img src="images/events/event/event5.jpg" class="img-fluid" alt="Image">
      </a>
    </figure>
  </div>
  <!-- ITEM -->
  <div class="col-md-3">
    <figure class="gradient-overlay-hover image-icon">
      <a href="images/events/event/event6.jpg">
        <img src="images/events/event/event6.jpg" class="img-fluid" alt="Image">
      </a>
    </figure>
  </div>
  <!-- ITEM -->
  <div class="col-md-3">
    <figure class="gradient-overlay-hover image-icon">
      <a href="images/events/event/event7.jpg">
        <img src="images/events/event/event7.jpg" class="img-fluid" alt="Image">
      </a>
    </figure>
  </div>
  <!-- ITEM -->
  <div class="col-md-3">
    <figure class="gradient-overlay-hover image-icon">
      <a href="images/events/event/event8.jpg">
        <img src="images/events/event/event8.jpg" class="img-fluid" alt="Image">
      </a>
    </figure>
  </div>
</div>
