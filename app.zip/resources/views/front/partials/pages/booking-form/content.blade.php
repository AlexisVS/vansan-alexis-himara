<div class="section-title">
  <h4>BOOK YOUR STAY</h4>
  <p class="section-subtitle">Book your Room Now</p>
</div>
<p class="mb30">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Mollitia deleniti fuga recusandae
  perferendis modi voluptate, ad ratione saepe voluptas nam provident reiciendis velit nulla repellendus
  illo consequuntur amet similique hic.
</p>
