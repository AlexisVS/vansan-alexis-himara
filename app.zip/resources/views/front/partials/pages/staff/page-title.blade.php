<div class="page-title gradient-overlay op6" style="background: url('{{ asset('images/breadcrumb.jpg') }}'); background-repeat: no-repeat;
background-size: cover;">
  <div class="container">
    <div class="inner">
      <h1>OUR STAFF</h1>
      <ol class="breadcrumb">
        <li>
          <a href="/">Home</a>
        </li>
        <li>Our Staff</li>
      </ol>
    </div>
  </div>
</div>
