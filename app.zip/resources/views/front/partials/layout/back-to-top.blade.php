<div class="back-to-top">
  <i class="fa fa-angle-up" aria-hidden="true"></i>
</div>
