<div id="booking-notification" class="notification fixed"></div>
