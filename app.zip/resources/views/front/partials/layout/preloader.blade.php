<div class="loader loader3">
  <div class="loader-inner">
    <div class="spin">
      <span></span>
      <img src="{{ asset('images/logo.svg') }}" alt="Hotel Himara">
    </div>
  </div>
</div>
